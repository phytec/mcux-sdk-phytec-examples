#!/bin/sh
rm -rf flexspi_nor_debug flexspi_nor_release CMakeFiles
rm -rf Makefile cmake_install.cmake CMakeCache.txt
